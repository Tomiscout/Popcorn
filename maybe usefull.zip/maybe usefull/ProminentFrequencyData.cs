﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoBlazor.SegmentFinder;

public class ProminentFrequencyData
{
    public (int LowerBound, int UpperBound) Band { get; set; }
    public int Index { get; set; }
    public double Magnitude { get; set; }
}
