﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoBlazor.SegmentFinder;
public static class EnumerableExtensions
{
    // https://stackoverflow.com/a/19545932/6104386
    public static IEnumerable<(T, T)> Pairwise<T>(this IEnumerable<T> enumerable)
    {
        var previous = default(T);

        using (var e = enumerable.GetEnumerator())
        {
            if (e.MoveNext())
                previous = e.Current;

            while (e.MoveNext())
                yield return (previous, previous = e.Current);
        }
    }
}