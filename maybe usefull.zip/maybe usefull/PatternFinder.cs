﻿using MathNet.Numerics;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static VideoBlazor.SegmentFinder.PeakBuilder;

namespace VideoBlazor.SegmentFinder;
public class PatternFinder
{
    #region old
    private const int SLIVER_WINDOW_COUNT = 10;
    private const double SLIVER_DURATION = 1.0 / 20.0;

    public static List<SegmentLocation> IdentifyJingle(
    ProminentFrequencyData[][] prominentFrequencies1,
    ProminentFrequencyData[][] prominentFrequencies2)
    {
        List<SegmentLocation> jingleLocations = new();

        for (int i = 0; i < prominentFrequencies1.Length - SLIVER_WINDOW_COUNT; i++)
        {
            var segment1 = prominentFrequencies1[i..(i + SLIVER_WINDOW_COUNT)];
            var peakCount1 = segment1.SelectMany(s => s).Count();

            for (int j = 0; j < prominentFrequencies2.Length - SLIVER_WINDOW_COUNT; j++)
            {
                var segment2 = prominentFrequencies2[j..(j + SLIVER_WINDOW_COUNT)];
                var peakCount2 = segment2.SelectMany(s => s).Count();

                if (Math.Abs(peakCount1 - peakCount2) > 2)
                {
                    continue;
                }

                int score = 0;
                for (int k = 0; k < SLIVER_WINDOW_COUNT; k++)
                {
                    score += ScoreMatch(segment1[k], segment2[k]);
                }

                if (score < Math.Min(peakCount1, peakCount2))
                {
                    continue;
                }

                int extend = 1;
                while (
                    i + SLIVER_WINDOW_COUNT + (extend * SLIVER_WINDOW_COUNT) < prominentFrequencies1.Length
                    && j + SLIVER_WINDOW_COUNT + (extend * SLIVER_WINDOW_COUNT) < prominentFrequencies2.Length)
                {
                    var nextSegment1 = prominentFrequencies1[(i + (extend * SLIVER_WINDOW_COUNT))..(i + (extend * SLIVER_WINDOW_COUNT) + SLIVER_WINDOW_COUNT)];
                    var nextSegment2 = prominentFrequencies2[(j + (extend * SLIVER_WINDOW_COUNT))..(j + (extend * SLIVER_WINDOW_COUNT) + SLIVER_WINDOW_COUNT)];
                    int nextScore = 0;
                    for (int k = 0; k < SLIVER_WINDOW_COUNT; k++)
                    {
                        nextScore += ScoreMatch(nextSegment1[k], nextSegment2[k]);
                    }

                    int nextPeakCount1 = nextSegment1.SelectMany(s => s).Count();
                    int nextPeakCount2 = nextSegment2.SelectMany(s => s).Count();
                    if (nextScore >= Math.Min(nextPeakCount1, nextPeakCount2))
                    {
                        extend++;
                    }
                    else
                    {
                        break;
                    }
                }

                double start1 = i * SLIVER_DURATION;
                double start2 = j * SLIVER_DURATION;
                double length = (extend * SLIVER_WINDOW_COUNT) * SLIVER_DURATION;

                jingleLocations.Add(new SegmentLocation()
                {
                    Start1 = start1,
                    Start2 = start2,
                    Length = length
                });

                // Skip the slivers that were part of a continuous match
                i += (extend * SLIVER_WINDOW_COUNT) + SLIVER_WINDOW_COUNT - 1;  // Adjusting the index
                j += (extend * SLIVER_WINDOW_COUNT) + SLIVER_WINDOW_COUNT - 1;  // Adjusting the index
            }
        }

        return jingleLocations;
    }

    //Could be prettier, but need the performance here
    public static int ScoreMatch(ProminentFrequencyData[] windowFrequencies, ProminentFrequencyData[] segmentFrequencies)
    {
        int score = 0;

        for (int i = windowFrequencies.Length - 1; i >= 0; i--)
        {
            var windowFrequency = windowFrequencies[i];
            for (int j = segmentFrequencies.Length - 1; j >= 0; j--)
            {
                var segmentFrequency = segmentFrequencies[j];
                if (windowFrequency.Band == segmentFrequency.Band &&
                    Math.Abs(windowFrequency.Magnitude - segmentFrequency.Magnitude) <= 2)
                {
                    score++;
                    break;
                }
            }
        }

        return score;
    }
    #endregion

    public static List<SegmentLocation> IdentifyJingle(
    Dictionary<int, PeakInfo[]> peaks1,
    Dictionary<int, PeakInfo[]> peaks2,
    int matchThreshold = 5, // This can be adjusted based on how many consecutive matches you require
    double timeResolution = 1f / SliverBuilder.CHUNKS_PER_SECOND
)
    {
        var matchingSegments = new List<SegmentLocation>();
        HashedPeak[] patterns1;
        HashedPeak[] patterns2;
        using (MD5 md5 = MD5.Create())
        {
            // Create a pattern signature for each entry in peaks1 and peaks2
            patterns1 = CreatePatternSignatures(peaks1, md5);
            patterns2 = CreatePatternSignatures(peaks2, md5);
        }

        var lastJIndex = 0; //So that on second match it wouldn't scan in the past.
        for (var i = 0; i < patterns1.Length; i++)
        {
            for (var j = lastJIndex; j < patterns2.Length; j++)
            {
                if (patterns1[i] != patterns2[j])
                {
                    continue;
                }

                int matches = 1;

                //If matches - while
                while (i+matches < patterns1.Length && j+matches < patterns2.Length && patterns1[i+matches] == patterns2[j+matches])
                {
                    matches++;
                }

                matchingSegments.Add(new SegmentLocation
                {
                    Start1 = patterns1[i].stripeIndex * timeResolution,
                    Start2 = patterns2[j].stripeIndex * timeResolution,
                    Length = (patterns1[i+matches - 1].stripeIndex - patterns1[i].stripeIndex) * timeResolution
                });

                //Skip matched count
                i += matches;
                //lastJIndex = j + matches - 1;
                break;
            }
        }

        return matchingSegments;
    }


    // Helper method to count non-null peaks in a PeakInfo array
    public static int CountNonNullPeaks(PeakInfo[] peaks)
    {
        return peaks.Count(peak => peak != null);
    }

    record HashedPeak(
        int stripeIndex,
        string hash
        );

    private static HashedPeak[] CreatePatternSignatures(Dictionary<int, PeakInfo[]> peaks, MD5 md5)
    {
        var patterns = new List<HashedPeak>();

        foreach (var entry in peaks)
        {
            // Use a string builder to create a concatenated string of all the bin values (and magnitudes if desired)
            var stringBuilder = new StringBuilder();

            foreach (var peak in entry.Value)
            {
                if (peak != null)
                {
                    stringBuilder.Append(peak.InterpolatedBin.ToString("F2"));
                    stringBuilder.Append(":"); // Delimiter
                    stringBuilder.Append(peak.LogMagnitude.ToString("F2"));
                    stringBuilder.Append("|"); // Delimiter
                } else
                {
                    stringBuilder.Append("|"); // Delimiter
                }
            }

            // Create a hash from the concatenated string
            
            patterns.Add(new HashedPeak(entry.Key, HashPeak(stringBuilder.ToString(), md5)));
        }

        return patterns.ToArray();
    }

    private static string HashPeak(string value, MD5 md5)
    {
        var hash = md5.ComputeHash(Encoding.UTF8.GetBytes(value));
        StringBuilder hex = new StringBuilder(hash.Length * 2);
        foreach (byte b in hash)
        {
            // Use "x2" format to convert the byte to a two-character lowercase hexadecimal string.
            hex.AppendFormat("{0:x2}", b);
        }
        return hex.ToString();
    }


    // Defines the tolerance for how close the LogMagnitudes need to be to consider a match
    private const float MagnitudeTolerance = 0.5f;

    // Scores the match between two arrays of PeakInfo
    // Returns the count of matching peaks
    public static int ScoreMatch(PeakInfo[] peaks1, PeakInfo[] peaks2)
    {
        int score = 0;
        int index1 = 0, index2 = 0;

        // Assuming peaks are sorted by StripeIndex and then by InterpolatedBin
        while (index1 < peaks1.Length && index2 < peaks2.Length)
        {
            var peak1 = peaks1[index1];
            var peak2 = peaks2[index2];

            if (peak1.StripeIndex == peak2.StripeIndex)
            {
                if (Math.Abs(peak1.LogMagnitude - peak2.LogMagnitude) <= MagnitudeTolerance)
                {
                    // A match is found
                    score++;
                    index1++;
                    index2++;
                }
                else if (peak1.LogMagnitude < peak2.LogMagnitude)
                {
                    // If peak1's magnitude is less than peak2's, increment index1 to find a possible match
                    index1++;
                }
                else
                {
                    // If peak2's magnitude is less than peak1's, increment index2 to find a possible match
                    index2++;
                }
            }
            else if (peak1.StripeIndex < peak2.StripeIndex)
            {
                // Move to the next peak in the first array if its stripe index is less
                index1++;
            }
            else
            {
                // Move to the next peak in the second array if its stripe index is less
                index2++;
            }
        }

        return score;
    }

}
