﻿using MathNet.Numerics.IntegralTransforms;
using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace VideoBlazor.SegmentFinder;
public static class SpectogramBuilder
{
    public static Bitmap CreateSpectrogram(Complex[][] binsPerSliver)
    {
        int sliverCount = binsPerSliver.Count();
        int bandMax = binsPerSliver[0].Length;
        var image = new Bitmap(sliverCount, bandMax, PixelFormat.Format24bppRgb);  // RGB image with expanded size

        // Find the min and max magnitude in the data
        float minMagnitude = binsPerSliver.Min(sliver => sliver.Min(c => (float)c.Magnitude));
        float maxMagnitude = binsPerSliver.Max(sliver => sliver.Max(c => (float)c.Magnitude));

        // Avoid division by zero and log of zero issues
        float range = Math.Max(maxMagnitude - minMagnitude, 1e-6f);

        for (int i = 0; i < sliverCount; i++)
        {
            var complexSliver = binsPerSliver[i];
            for (int j = 0; j < bandMax; j++)
            {
                // Convert magnitude to intensity
                var magnitude = (float)((complexSliver[j].Magnitude - minMagnitude) / range);

                var intensity = (int)(magnitude * 255);
                intensity = Math.Min(intensity, 255);  // Clip intensity at 255

                // Get color based on frequency and intensity
                //var color = GetColorFromFrequency(j, bandMax, intensity);
                var color = Color.FromArgb(255, intensity, intensity, intensity);
                image.SetPixel(i, bandMax - j - 1, color);
            }
        }

        return image;
    }

    private static Color GetColorFromFrequency(int binIndex, int bandMax, int intensity)
    {
        var frequency = (binIndex * 1.0 / bandMax) * 7180;  // Max frequency is 7180
        Color baseColor;
        if (frequency < 100) baseColor = Color.LightSalmon;
        else if (frequency < 200) baseColor = Color.Green;
        else if (frequency < 400) baseColor = Color.Blue;
        else if (frequency < 800) baseColor = Color.Yellow;
        else if (frequency < 1600) baseColor = Color.Cyan;
        else baseColor = Color.Pink;  // Frequency >= 1600

        // Adjust RGB values based on intensity while keeping alpha channel fully opaque
        return Color.FromArgb(
            255,
            (int)(baseColor.R * intensity / 255.0),
            (int)(baseColor.G * intensity / 255.0),
            (int)(baseColor.B * intensity / 255.0)
        );
    }


    public static void OverlayPeaksOnSpectrogram(ProminentFrequencyData[][] prominentFrequencies, ref Bitmap spectrogram)
    {
        var sliverCount = prominentFrequencies.Length;
        var frequencyBandCount = SegmentFinder.FREQUENCY_BANDS.Length - 1;  // Number of frequency bands
        var bandMax = prominentFrequencies[0].Length;

        for (int i = 0; i < sliverCount; i++)
        {
            var sliverPeaks = prominentFrequencies[i];
            foreach (var peak in sliverPeaks)
            {
                var bandIndex = Array.IndexOf(SegmentFinder.FREQUENCY_BANDS, peak.Band.Item1);  // Find the index of the frequency band for this peak
                if (bandIndex >= 0)
                {
                    // Map the peak.Index value to the y-coordinate on the spectrogram
                    int y = bandMax - ((peak.Index - peak.Band.Item1) * frequencyBandCount / (peak.Band.Item2 - peak.Band.Item1) + bandIndex * frequencyBandCount) - 1;

                    // Draw a red rectangle (10x3 pixels) for each peak
                    for (int x = i - 5; x <= i + 5; x++)  // 10 px width
                    {
                        for (int dy = y - 1; dy <= y + 1; dy++)  // 3 px height
                        {
                            if (x >= 0 && x < spectrogram.Width && dy >= 0 && dy < spectrogram.Height)
                            {
                                spectrogram.SetPixel(x, dy, Color.Red);
                            }
                        }
                    }
                }
            }
        }
    }


}
