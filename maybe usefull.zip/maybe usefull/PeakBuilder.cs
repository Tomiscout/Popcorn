﻿using NAudio.Codecs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace VideoBlazor.SegmentFinder;
public static class PeakBuilder
{
    #region old
    public static ProminentFrequencyData[][] GetProminentFrequencies(Complex[][] binsPerSliver)
    {
        var binBands = GetBandsForFrequency(binsPerSliver.Length);

        return binsPerSliver.Select(bins => FindTopBinIndices(bins, binBands)).ToArray();
    }

    private static IList<(int, int)> GetBandsForFrequency(int frequency)
    {
        var binSize = frequency / SegmentFinder.BIN_COUNT;
        return SegmentFinder.FREQUENCY_BANDS
            .Select(f => (int)Math.Round((double)f / binSize))
            .Pairwise()
            .ToList();
    }

    private static ProminentFrequencyData FindTopBinPairInBand(Complex[] frequencyData, (int, int) binBand)
    {
        var (lb, ub) = binBand;
        var maxPair = frequencyData
        .Skip(lb)
        .Take(ub - lb)
        .Select((binValue, index) => (binValue.Magnitude, Index: index + lb))  // Adjusting index to account for Skip
        .Aggregate((max, current) => (current.Magnitude > max.Magnitude) ? current : max);  // Find max pair based on magnitude

        return new ProminentFrequencyData
        {
            Band = binBand,
            Index = maxPair.Index,
            Magnitude = maxPair.Magnitude
        };
    }

    private static ProminentFrequencyData[] FindTopBinIndices(Complex[] frequencyData, IEnumerable<(int, int)> binBands)
    {
        var topBinsPairs = binBands.Select(binBand => FindTopBinPairInBand(frequencyData, binBand));

        //Takes frequency peaks higher than average of the whole sliver, basically filters out more quiet data
        var meanBinValue = topBinsPairs.Average(pair => pair.Magnitude);
        var threshold = Math.Max(meanBinValue, 0);  // assuming a minimum bin value of 0
        return topBinsPairs
            .Where(pair => pair.Magnitude >= threshold)
            .ToArray();
    }
    #endregion

    public record PeakInfo(
    int StripeIndex,
    float InterpolatedBin,
    float LogMagnitude
);

    public const int
            // Refer to Test/PeakDensityResearch.Fat()
            H_STRIPE_DIST = 45, H_BIN_DIST = 1,
            V_STRIPE_DIST = 3, V_BIN_DIST = 10;

    static readonly IReadOnlyList<int> BAND_FREQS = new[] { 250, 520, 1450, 3500, 5500 };

    static readonly int
        MIN_BIN = Math.Max(SliverBuilder.FreqToBin(BAND_FREQS.Min()), V_BIN_DIST),
        MAX_BIN = Math.Min(SliverBuilder.FreqToBin(BAND_FREQS.Max()), SliverBuilder.BIN_COUNT - V_BIN_DIST);

    static readonly float
        MIN_MAGN_SQUARED = 1f / 512 / 512,
        LOG_MIN_MAGN_SQUARED = MathF.Log(MIN_MAGN_SQUARED);


    //TODO this is not efficient, rewrite later
    public static Dictionary<int, PeakInfo[]> FindAllPeaks(float[][] fftData)
    {
        // Create a List to hold all bands as it was originally
        var bands = Enumerable.Range(0, BAND_FREQS.Count - 1)
                              .Select(_ => new List<PeakInfo>())
                              .ToList();

        // Process each stripe (FFT chunk)
        for (int stripe = 0; stripe < fftData.Length; ++stripe)
        {
            FindPeaksForStripe(fftData, bands, stripe);
        }

        // Transform the List<List<PeakInfo>> into a Dictionary<int, PeakInfo[]>
        var peaksDictionary = new Dictionary<int, PeakInfo[]>();

        for (int stripe = 0; stripe < fftData.Length; stripe++)
        {
            // Create an array for the current stripe with null values as placeholders
            PeakInfo[] peakInfos = new PeakInfo[4]; // Assuming there are 4 frequency bands

            // Iterate through each frequency band
            for (int bandIndex = 0; bandIndex < peakInfos.Length; bandIndex++)
            {
                // If there's a peak for the current band at the current stripe, take it
                if (bandIndex < bands.Count && bands[bandIndex].Any(peak => peak.StripeIndex == stripe))
                {
                    peakInfos[bandIndex] = bands[bandIndex].FirstOrDefault(peak => peak.StripeIndex == stripe);
                }
                // Else it stays null
            }

            // Only add to dictionary if there's at least one non-null PeakInfo in the array
            if (peakInfos.Any(peakInfo => peakInfo != null))
            {
                peaksDictionary.Add(stripe, peakInfos);
            }
        }

        return peaksDictionary;
    }

    private static void FindPeaksForStripe(float[][] fftData, List<List<PeakInfo>> bands, int stripe)
    {
        // Assuming fftData[stripe] contains the magnitude squared data for each bin
        for (var bin = MIN_BIN; bin < MAX_BIN; bin++)
        {
            if (fftData[stripe][bin] < MIN_MAGN_SQUARED)
                continue;

            if (!IsPeak(fftData, stripe, bin, H_STRIPE_DIST, H_BIN_DIST))
                continue;

            if (!IsPeak(fftData, stripe, bin, V_STRIPE_DIST, V_BIN_DIST))
                continue;

            AddPeakAt(fftData, bands, stripe, bin);
        }
    }

   /* public void ApplyRateLimit()
    {
        // Derived by comparison with official signature
        // StripeCount / 11 also works
        var allowedCount = 12 + Analysis.StripeCount / 12;

        foreach (var peakList in Bands)
        {
            if (peakList.Count <= allowedCount)
                continue;

            peakList.Sort((x, y) => -Comparer<Single>.Default.Compare(x.LogMagnitude, y.LogMagnitude));
            peakList.RemoveRange(allowedCount, peakList.Count - allowedCount);
            peakList.Sort((x, y) => Comparer<Int32>.Default.Compare(x.StripeIndex, y.StripeIndex));
        }
    }*/

    static int GetBandIndex(float bin)
    {
        var freq = SliverBuilder.BinToFreq(bin);

        if (freq < BAND_FREQS[0])
            return -1;

        for (var i = 1; i < BAND_FREQS.Count; i++)
        {
            if (freq < BAND_FREQS[i])
                return i - 1;
        }

        return -1;
    }

    static PeakInfo CreatePeakAt(float[][] data, int stripe, int bin)
    {
        /* interpolation off
        if (!Interpolation)
        {
            return new PeakInfo(stripe, bin, GetLogMagnitude(stripe, bin));
        }*/

        // Quadratic Interpolation of Spectral Peaks
        // https://stackoverflow.com/a/59140547
        // https://ccrma.stanford.edu/~jos/sasp/Quadratic_Interpolation_Spectral_Peaks.html

        // https://ccrma.stanford.edu/~jos/parshl/Peak_Detection_Steps_3.html
        // "We have found empirically that the frequencies tend to be about twice as accurate"
        // "when dB magnitude is used rather than just linear magnitude"

        var alpha = GetLogMagnitude(data, stripe, bin - 1);
        var beta = GetLogMagnitude(data, stripe, bin);
        var gamma = GetLogMagnitude(data, stripe, bin + 1);
        var p = (alpha - gamma) / (alpha - 2 * beta + gamma) / 2;

        return new PeakInfo(
            stripe,
            bin + p,
            beta // - (alpha - gamma) * p / 4
        );
    }

    static float GetLogMagnitude(float[][] data, int stripe, int bin)
    {
        return 18 * 1024 * (1 - MathF.Log(data[stripe][bin]) / LOG_MIN_MAGN_SQUARED);
    }

    static bool IsPeak(float[][] data, int stripe, int bin, int stripeDist, int binDist)
    {
        var center = data[stripe][bin];

        for (var s = -stripeDist; s <= stripeDist; s++)
        {
            int currentStripe = stripe + s;
            // Check that the current stripe is within the bounds of the data array
            if (currentStripe < 0 || currentStripe >= data.Length)
                continue;

            for (var b = -binDist; b <= binDist; b++)
            {
                int currentBin = bin + b;
                // Check that the current bin is within the bounds of the stripe array
                if (currentBin < 0 || currentBin >= data[stripe].Length)
                    continue;

                if (s == 0 && b == 0)
                    continue;

                if (data[currentStripe][currentBin] >= center)
                    return false;
            }
        }

        return true;
    }


    static void AddPeakAt(float[][] data, List<List<PeakInfo>> bands, int stripe, int bin)
    {
        var newPeak = CreatePeakAt(data, stripe, bin);

        var bandIndex = GetBandIndex(newPeak.InterpolatedBin);
        if (bandIndex < 0)
            return;

        bands[bandIndex].Add(newPeak); //mutations are bad, but im lazy
    }
}
