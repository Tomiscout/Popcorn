﻿using MathNet.Numerics;
using MathNet.Numerics.IntegralTransforms;
using NAudio.Wave;
using System.Numerics;

namespace VideoBlazor.SegmentFinder;
internal static class SliverBuilder
{
    public static Complex[][] GetSliverData(string path)
    {
        using var reader = new AudioFileReader(path);
        var sampleProvider = reader.ToSampleProvider().ToMono();

        var sampleRate = reader.WaveFormat.SampleRate;
        var totalSamples = reader.Length / (reader.WaveFormat.BitsPerSample / 8);
        var duration = totalSamples / sampleRate;
        var sliverCount = (int)Math.Floor(duration / SegmentFinder.SLIVER_DURATION);
        var sliverLength = (int)Math.Floor(sampleRate * SegmentFinder.SLIVER_DURATION);

        var samples = new float[totalSamples];
        sampleProvider.Read(samples, 0, (int)totalSamples);

        var binsPerSliver = Enumerable.Range(0, sliverCount) //TODO rewrite this linq
         .Select(index => samples.Skip(index * sliverLength).Take(sliverLength).ToArray())
         .Select(sliver =>
         {
             var complexSliver = sliver.Select(sample => new Complex(sample, 0)).ToArray();
             Fourier.Forward(complexSliver, FourierOptions.Default);
             return complexSliver;
         })
         .ToArray();

        return binsPerSliver;
    }


    public const int SAMPLE_RATE = 16000;
    public const int CHUNKS_PER_SECOND = 125;
    public const int CHUNK_SIZE = SAMPLE_RATE / CHUNKS_PER_SECOND;
    public const int WINDOW_SIZE = CHUNK_SIZE * 16;
    public const int BIN_COUNT = WINDOW_SIZE / 2 + 1;

    public static float[][] GetSliverData2(string path)
    {
        using var reader = new AudioFileReader(path);
        var sampleProvider = reader.ToSampleProvider().ToMono();

        var sampleRate = reader.WaveFormat.SampleRate;
        var totalSamples = reader.Length / (reader.WaveFormat.BitsPerSample / 8);
        var sliverCount = (int)Math.Floor((double)totalSamples / sampleRate / SegmentFinder.SLIVER_DURATION);
        var sliverLength = (int)Math.Floor(sampleRate * SegmentFinder.SLIVER_DURATION);
        var hannWindow = GenerateHannWindow(sliverLength);

        var samples = new float[totalSamples];
        sampleProvider.Read(samples, 0, (int)totalSamples);

        var slivers = new float[sliverCount][];
        for (int index = 0; index < sliverCount; index++)
        {
            var sliverSamples = samples
            .Skip(index * sliverLength)
            .Take(sliverLength)
            .Select((sample, i) => sample * hannWindow[i])
            .ToArray();

            var sliver = sliverSamples
                .Select(sample => new Complex(sample, 0))
                .ToArray();

            Fourier.Forward(sliver, FourierOptions.NoScaling);

            // Used in official Shazam since 7.11.0
            // https://github.com/marin-m/SongRec/issues/10#issuecomment-731527377
            slivers[index] = sliver.Select(c => (float)c.MagnitudeSquared() * 2).ToArray();
        }

        return slivers;
    }

    private static float[] GenerateHannWindow(int length)
    {
        var window = new float[length];
        for (int i = 0; i < length; i++)
        {
            window[i] = (float)(0.5 * (1 - Math.Cos(2 * Math.PI * i / (length - 1))));
        }
        return window;
    }

    public static float FindMaxMagnitudeSquared(float[][] slivers)
    {
        return slivers.Max(s => s.Max());
    }

    public static int FreqToBin(float freq)
    {
        return Convert.ToInt32(freq * WINDOW_SIZE / SAMPLE_RATE);
    }

    public static float BinToFreq(float bin)
    {
        return bin * SAMPLE_RATE / WINDOW_SIZE;
    }

}